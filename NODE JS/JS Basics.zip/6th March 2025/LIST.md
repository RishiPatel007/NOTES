---

kanban-plugin: board

---

## JS BASICS

- [x] [[Errors and Types of error]]
- [x] [[Arrays]]
- [x] [[Object]]
- [x] [[Execution Context , Scope & Hoisting]]
- [x] [[Function]]
- [x] [[Callback]]
- [x] [[Promise , Async - await]]
- [x] [[This]]
- [x] [[Classes]]
- [x] [[Super]]
- [x] [[Prototype]]
- [x] [[Javascript Modules and Export]]




%% kanban:settings
```
{"kanban-plugin":"board","list-collapse":[false],"show-checkboxes":true}
```
%%